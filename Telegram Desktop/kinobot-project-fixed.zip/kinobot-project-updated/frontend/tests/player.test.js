// frontend/tests/player.test.js
// KinoBotPlayer (frontend/js/player.js) uchun testlar.
// Video element va DOM minimal stub bilan simulyatsiya qilinadi.
// Video endi bitta manbadan keladi (Telegram storage-kanal, MTProto) —
// movie.hasVideo boolean va resolveUrl() orqali (async, tokenli URL).
//   - load: hasVideo bo'lsa manba, aks holda empty holat
//   - resolveUrl orqali src o'rnatilishi (progressive, async)
//   - qualities()/setQuality(): bitta manba — quality chip doim yashirin
//   - resume: loadedmetadata da positionSeconds'dan davom ettirish
//   - progress debounce: 5s/10s qoidasi bilan onProgress chaqirilishi

"use strict";

const { test } = require("node:test");
const assert = require("node:assert");
const path = require("node:path");

require(path.join(__dirname, "helpers", "domStub.js"));

const PLAYER_JS = path.join(__dirname, "..", "js", "player.js");

// --- video element stub ---
function makeVideo() {
  return {
    hidden: true,
    src: "",
    paused: true,
    duration: 0,
    currentTime: 0,
    onloadedmetadata: null,
    ontimeupdate: null,
    onended: null,
    _played: 0,
    play() { this.paused = false; this._played++; return Promise.resolve(); },
    pause() { this.paused = true; },
    removeAttribute(attr) { if (attr === "src") this.src = ""; },
    canPlayType() { return ""; }, // default: HLS native yo'q
  };
}

function makeQualityEl() {
  return { hidden: true, innerHTML: "" };
}

// document stub — faqat player moduli ishlatadigan qismlar.
function installDocument() {
  global.document = {
    _nodes: {},
    getElementById(id) {
      if (!this._nodes[id]) {
        this._nodes[id] = { style: {}, hidden: true, innerHTML: "" };
      }
      return this._nodes[id];
    },
    createElement(tag) {
      return { tagName: String(tag).toUpperCase(), src: "", onload: null, onerror: null };
    },
    head: { appendChild() {} },
  };
  return global.document;
}

// Promise zanjiridagi .then() callback'larini kutadi (resolveUrl() async,
// _applySource shundan keyin video.src'ni o'rnatadi).
async function tick() {
  await new Promise((r) => setTimeout(r, 0));
  await new Promise((r) => setTimeout(r, 0));
}

// player.js'ni toza yuklaydi va { player, video, qualityEl } qaytaradi.
function freshPlayer(opts = {}) {
  delete require.cache[require.resolve(PLAYER_JS)];
  require(PLAYER_JS);
  const player = global.window.KinoBotPlayer;
  const video = opts.video || makeVideo();
  const qualityEl = opts.qualityEl || makeQualityEl();
  player.init(video, qualityEl);
  return { player, video, qualityEl };
}

function resolveUrlTo(url) {
  return () => Promise.resolve(url);
}

// --- load / hasVideo ---
test("load: hasVideo=true bo'lsa true qaytadi, video ko'rsatiladi", () => {
  const { player, video } = freshPlayer();
  const loaded = player.load({ id: "m1", hasVideo: true }, { resolveUrl: resolveUrlTo("https://x.test/v.mp4") });
  assert.equal(loaded, true);
  assert.equal(video.hidden, false);
});

test("load: hasVideo=false bo'lsa false qaytadi va video yashiriladi", () => {
  installDocument();
  const { player, video } = freshPlayer();
  const loaded = player.load({ id: "m2", hasVideo: false }, {});
  assert.equal(loaded, false);
  assert.equal(video.hidden, true);
});

test("load: hasVideo yo'q (undefined) bo'lsa ham false qaytadi", () => {
  installDocument();
  const { player, video } = freshPlayer();
  const loaded = player.load({ id: "m2b" }, {});
  assert.equal(loaded, false);
  assert.equal(video.hidden, true);
});

test("load: resolveUrl orqali olingan URL video.src'ga o'rnatiladi (async)", async () => {
  const { player, video } = freshPlayer();
  player.load({ id: "m3", hasVideo: true }, { resolveUrl: resolveUrlTo("https://x.test/telegram-stream.mp4") });
  await tick();
  assert.equal(video.src, "https://x.test/telegram-stream.mp4");
});

test("load: resolveUrl mavjud bo'lmasa xato chiqadi (onError)", async () => {
  const errors = [];
  const { player } = freshPlayer();
  player.load({ id: "m4", hasVideo: true }, { onError: (msg) => errors.push(msg) });
  await tick();
  assert.equal(errors.length, 1);
});

test("load: resolveUrl reject/noto'g'ri qiymat qaytarsa onError chaqiriladi", async () => {
  const errors = [];
  const { player } = freshPlayer();
  player.load({ id: "m5", hasVideo: true }, {
    resolveUrl: () => Promise.resolve(null),
    onError: (msg) => errors.push(msg),
  });
  await tick();
  assert.equal(errors.length, 1);
});

test("load: bitta manba bo'lgani uchun quality chip doim yashirin", async () => {
  const { player, qualityEl } = freshPlayer();
  player.load({ id: "m6", hasVideo: true }, { resolveUrl: resolveUrlTo("https://x.test/v.mp4") });
  await tick();
  assert.equal(qualityEl.hidden, true);
  assert.deepEqual(player.qualities(), [{ label: "", active: true }]);
});

// --- resume ---
test("resume: loadedmetadata da resumeAt pozitsiyasiga o'tadi", () => {
  const { player, video } = freshPlayer();
  player.load({ id: "m8", hasVideo: true }, { resumeAt: 120, resolveUrl: resolveUrlTo("https://x.test/v.mp4") });
  video.duration = 600;
  assert.equal(video.currentTime, 0); // hali metadata yo'q
  video.onloadedmetadata(); // metadata keldi
  assert.equal(video.currentTime, 120);
  assert.equal(video._played, 1);
});

test("resume: resumeAt 0 bo'lsa boshidan o'ynaydi", () => {
  const { player, video } = freshPlayer();
  player.load({ id: "m9", hasVideo: true }, { resumeAt: 0, resolveUrl: resolveUrlTo("https://x.test/v.mp4") });
  video.duration = 600;
  video.onloadedmetadata();
  assert.equal(video.currentTime, 0);
});

// --- progress debounce ---
test("progress: 5s/10s debounce qoidasi bilan onProgress chaqiriladi", () => {
  const calls = [];
  const { player, video } = freshPlayer();
  player.load({ id: "m10", hasVideo: true }, {
    resolveUrl: resolveUrlTo("https://x.test/v.mp4"),
    onProgress: (pct, pos) => calls.push([pct, pos]),
  });
  video.duration = 600;

  // 30s -> pct=5 (30/600), first save (lastSaveAt=0 -> yetarli vaqt o'tgan)
  video.currentTime = 30;
  player.lastPos = 0;
  player.lastSaveAt = 0;
  video.ontimeupdate();
  assert.deepEqual(calls, [[5, 30]]);

  // 31s -> delta <5 -> chaqirilmaydi
  video.currentTime = 31;
  video.ontimeupdate();
  assert.equal(calls.length, 1);

  // 45s -> delta 14 >=5, vaqt o'tgan -> chaqiriladi (pct=8)
  video.currentTime = 45;
  player.lastSaveAt = 0;
  video.ontimeupdate();
  assert.equal(calls.length, 2);
  assert.deepEqual(calls[1], [8, 45]);
});

test("progress: oxirgi saqlashdan 10s o'tmagan bo'lsa chaqirilmaydi", () => {
  const calls = [];
  const { player, video } = freshPlayer();
  player.load({ id: "m11", hasVideo: true }, {
    resolveUrl: resolveUrlTo("https://x.test/v.mp4"),
    onProgress: (pct, pos) => calls.push([pct, pos]),
  });
  video.duration = 600;
  player.lastPos = 0;
  player.lastSaveAt = Date.now(); // hozirgina saqlandi
  video.currentTime = 60;
  video.ontimeupdate();
  assert.equal(calls.length, 0);
});

test("onended: callback chaqiriladi", () => {
  let ended = 0;
  const { player, video } = freshPlayer();
  player.load({ id: "m12", hasVideo: true }, {
    resolveUrl: resolveUrlTo("https://x.test/v.mp4"),
    onEnded: () => ended++,
  });
  video.onended();
  assert.equal(ended, 1);
});
