# Video avtomatik saqlash (Telegram MTProto)

Manba kanalga (`CHANNEL_ID`) video/hujjat-video tashlanganda, uni alohida
"storage" kanalga **avtomatik nusxalaydi** — Bot API'ning 20MB fayl
cheklovisiz, fayl qayta yuklanmasdan (Telegram serverida nusxalanadi).

Bu mavjud `#kod` va `*` (broadcast) xususiyatlari bilan **parallel**
ishlaydi, ularni almashtirmaydi. Frontend, REST API va bot buyruqlari
o'zgarmagan.

## Nega kerak

Bot API orqali fayl yuklab olish 20MB bilan cheklangan — kino fayllari
uchun ishlamaydi. MTProto (Telegram'ning to'liq protokoli) bu cheklovga ega
emas. `telegram` (GramJS) kutubxonasi shu protokolni Node.js'da amalga
oshiradi.

## Sozlash (3 qadam)

1. **npm paketi o'rnatish** (bir marta):
   ```bash
   cd backend && npm install
   ```

2. **`TELEGRAM_API_ID` / `TELEGRAM_API_HASH`** — https://my.telegram.org →
   "API development tools" → yangi ilova yarating (bepul). Bu shunchaki
   "ilova identifikatori" — alohida login/telefon kod talab qilmaydi, chunki
   bot o'zining mavjud `BOT_TOKEN`i bilan MTProto'ga kiradi.

3. **`STORAGE_CHANNEL_ID`** — yangi (yashirin bo'lishi mumkin) Telegram
   kanal yarating, botni o'sha kanalga **admin** qilib qo'shing, kanal
   ID'sini `.env`ga yozing (masalan `-1009876543210`).

`.env`:
```
TELEGRAM_API_ID=123456
TELEGRAM_API_HASH=abcdef0123456789abcdef0123456789
STORAGE_CHANNEL_ID=-1009876543210
```

Uchalasi ham bo'sh bo'lsa — xususiyat butunlay o'chiq turadi, hech nima
o'zgarmaydi (mavjud kinobot ishlashda davom etadi).

## Qanday ishlaydi

1. Admin `CHANNEL_ID` kanalga video joylaydi (caption bilan yoki captionsiz).
2. Bot (`bot.js`) buni `channel_post` update sifatida qabul qiladi.
3. Agar video/hujjat-video bo'lsa va yuqoridagi 3 ta o'zgaruvchi
   to'ldirilgan bo'lsa — `src/channelAutoSave.js` MTProto klient
   (`src/mtproto.js`) orqali xabarni `STORAGE_CHANNEL_ID`ga nusxalaydi
   (muallif/manba yorlig'isiz — oddiy "copy").
4. Yozuv `src/storageVideos.js` orqali `db.json`ga saqlanadi:
   `{ id, sourceChannelId, sourceMessageId, storageChannelId, storageMessageId, code, caption, fileName, fileSize, mimeType, mediaType, savedAt }`.
5. `ADMIN_ID` sozlangan bo'lsa, adminga natija haqida xabar keladi.

## Keyingi qadamlar (hozircha amalga oshirilmagan)

- Admin panelda "Kanal videolari" ro'yxatini `storageVideos.listEntries()`
  orqali ko'rsatish (REST endpoint qo'shish kerak).
- Veb-pleyerda shu storage-kanal videolarini to'g'ridan-to'g'ri strim
  qilish (Range so'rovlari bilan MTProto'dan chunk-chunk o'qish) —
  TelePlay'dagi `streaming.py` mantig'iga o'xshash, GramJS'ning
  `client.iterDownload()` metodidan foydalaniladi.

Bularni ham qilishni xohlasangiz, ayting — davom ettiraman.

---

## Tuzatish (2026-08-18): strim ishlamayotgan xato

`src/telegramStream.js` GramJS'ning `iterDownload()` metodiga oddiy JS
sonlarini uzatardi, lekin u `big-integer` obyektlarini kutadi (ichida
`.add()` / `.divide()` chaqiriladi). Natijada har bir strim so'rovi
`fileSize.add is not a function` xatosi bilan yiqilib, `catch` blokida
jimgina yutilardi — pleyerga **0 bayt** yetib borardi, hech qanday
ko'rinadigan xato chiqmasdan.

Tuzatilgan uchta narsa:

1. `offset` va `fileSize` endi `bigInt(...)` bilan uzatiladi.
2. `REQUEST_CHUNK` 1MB → **512KB**. GramJS ichida `MAX_CHUNK_SIZE = 512KB`,
   undan kattasi jimgina qisqartirilardi — natijada `alignedOffset` 1MB
   chegarasida hisoblanib, GramJS 512KB bilan ishlab, mos kelmasdi.
3. Backpressure: `res.write()` `false` qaytarsa endi `drain` kutiladi.
   Ilgari natija e'tiborsiz edi — katta kinoda Node'ning ichki buferi
   xotirani to'ldirib yuborishi mumkin edi.

Tekshirildi: 6 xil HTTP Range holati (butun fayl, birinchi 1KB, o'rtadan
seek, oxirgi 1MB, chunk chegarasi ustidan kesuvchi range) — barchasida
uzatilgan baytlar soni va har bir baytning qiymati to'g'ri. Loyihaning
mavjud 169 ta testi ham o'zgarishsiz o'tadi.

### Agar hali ham ishlamasa

Muammo strim emas, undan **oldingi** bosqichda bo'lishi mumkin. Kanalga
video tashlab, `backend/logs/bot.log` ni tekshiring:

- `MTProto klient ulandi ...` — yo'q bo'lsa: `TELEGRAM_API_ID` /
  `TELEGRAM_API_HASH` xato, yoki tarmoq muammosi.
- `✅ Video storage kanalga saqlandi ...` — yo'q bo'lsa: bot manba yoki
  storage kanalda **admin emas**, yoki `CHANNEL_ID` mos kelmayapti
  (`Kanal ID mos kelmadi` xabari chiqadi).
- `STORAGE_CHANNEL_ID` raqamli (`-100...`) formatda bo'lgani ma'qul.
