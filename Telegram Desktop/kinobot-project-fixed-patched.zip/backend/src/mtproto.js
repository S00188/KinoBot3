// src/mtproto.js
// Telegram MTProto klienti (GramJS) — Bot API'dan farqli, MTProto orqali
// ulanadi. Sabab: Bot API'da fayl yuklab olish 20MB bilan cheklangan,
// MTProto'da bunday cheklov yo'q (katta video fayllarni strim qilish /
// kanaldan-kanalga nusxalash uchun shu kerak).
//
// Bot TOKEN bilan MTProto'ga kiradi (client.start({ botAuthToken })) —
// alohida telefon raqami / login kodi kerak emas, faqat qo'shimcha
// TELEGRAM_API_ID va TELEGRAM_API_HASH (my.telegram.org'dan, bepul,
// istalgan Telegram akkauntga tegishli bo'lishi mumkin — bu shunchaki
// "ilova" identifikatori, alohida user login emas).
//
// Ushbu modul BUTUNLAY IXTIYORIY: agar TELEGRAM_API_ID / TELEGRAM_API_HASH
// .env'da bo'sh bo'lsa, mavjud bot.js va server.js funksiyalari (kod
// xaritasi, broadcast, R2/lokal video) hech qanday o'zgarishsiz avvalgidek
// ishlayveradi — bu modul faqat qo'shimcha "avtomatik saqlash" xususiyati
// yoqilganda ishga tushadi.

"use strict";

const fs = require("fs");
const path = require("path");

let TelegramClient, StringSession;
try {
  // Lazy require — "telegram" (gramjs) paketi o'rnatilmagan bo'lsa ham
  // (masalan bu xususiyat ishlatilmayotgan deploy'da) qolgan backend
  // yiqilib qolmasin.
  ({ TelegramClient } = require("telegram"));
  ({ StringSession } = require("telegram/sessions"));
} catch (e) {
  TelegramClient = null;
  StringSession = null;
}

const API_ID = process.env.TELEGRAM_API_ID ? Number(process.env.TELEGRAM_API_ID) : 0;
const API_HASH = process.env.TELEGRAM_API_HASH ? String(process.env.TELEGRAM_API_HASH).trim() : "";
const BOT_TOKEN = process.env.BOT_TOKEN || "";

const SESSION_PATH = path.join(__dirname, "..", "data", "telegram-mtproto-session.txt");

function isEnabled() {
  return !!(TelegramClient && API_ID && API_HASH && BOT_TOKEN);
}

function readSavedSession() {
  try {
    return fs.readFileSync(SESSION_PATH, "utf-8").trim();
  } catch (e) {
    return "";
  }
}

function saveSession(sessionString) {
  try {
    fs.mkdirSync(path.dirname(SESSION_PATH), { recursive: true });
    fs.writeFileSync(SESSION_PATH, sessionString, "utf-8");
  } catch (e) {
    console.warn("MTProto session saqlashda xato:", e.message);
  }
}

let client = null;
let startingPromise = null;

// Klientni ishga tushiradi (allaqachon ishga tushgan bo'lsa — mavjudini qaytaradi).
// Xatolikda `null` qaytaradi va konsolga yozadi — chaqiruvchi tomon shunchaki
// avtomatik-saqlash xususiyatini o'tkazib yuboradi, bot ishlashda davom etadi.
async function getClient() {
  if (!isEnabled()) return null;
  if (client && client.connected) return client;
  if (startingPromise) return startingPromise;

  startingPromise = (async () => {
    try {
      const savedSession = readSavedSession();
      const session = new StringSession(savedSession);
      const c = new TelegramClient(session, API_ID, API_HASH, {
        connectionRetries: 5,
      });

      await c.start({
        botAuthToken: BOT_TOKEN,
      });

      const sessionString = c.session.save();
      if (sessionString && sessionString !== savedSession) {
        saveSession(sessionString);
      }

      client = c;
      console.log("MTProto klient ulandi (video avtomatik-saqlash xususiyati faol).");
      return client;
    } catch (e) {
      console.error("MTProto klient ulanmadi:", e.message);
      client = null;
      return null;
    } finally {
      startingPromise = null;
    }
  })();

  return startingPromise;
}

async function stopClient() {
  if (client) {
    try {
      await client.disconnect();
    } catch (e) {
      /* e'tiborsiz */
    }
    client = null;
  }
}

module.exports = { isEnabled, getClient, stopClient };
